import numpy as np
import cv2
import os
import imutils
import time

error_list_x = np.load('error_list_x.npy')
error_list_y=np.load('error_list_y.npy')


def circshift(u,shiftnum1,shiftnum2):
    shiftnum1=-shiftnum1
    shiftnum2=-shiftnum2
    h,w = u.shape
    if shiftnum1 < 0:
        u = np.vstack((u[-shiftnum1:,:],u[:-shiftnum1,:]))
    else:
        u = np.vstack((u[(h-shiftnum1):,:],u[:(h-shiftnum1),:]))
    if shiftnum2 > 0:
        u = np.hstack((u[:, (w - shiftnum2):], u[:, :(w - shiftnum2)]))
    else:
        u = np.hstack((u[:,-shiftnum2:],u[:,:-shiftnum2]))
    return u


name_list=[]
for i in range(0,252):
    j=i
    i = i + 1
    # print(i)
    # print(filename)
    # picture_name ="cell_round%d.jpg" % (i)
    picture_name = "%d.jpg" % (i)
    name_list.append(picture_name)
    img = cv2.imread(os.path.join('segment_image', name_list[j]), 0)

    img_new=circshift(img, error_list_x[j], error_list_y[j])

    folder_name = 'result'
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    cv2.imwrite(os.path.join(folder_name, f'{i}.png'), img_new)

    cv2.imshow('img', img_new)
    cv2.waitKey(300)








