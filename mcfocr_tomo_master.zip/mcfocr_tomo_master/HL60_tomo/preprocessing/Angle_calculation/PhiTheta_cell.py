import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.io as io
import matplotlib.animation as animation
import h5py
import os
config = {
    "font.family": 'sans-serif',
    "font.serif": ['Arial',],
    "font.size": 16,
    "mathtext.fontset": 'stixsans',
}
plt.rcParams.update(config)

result_folder = 'result'
if not os.path.exists(result_folder):
    os.makedirs(result_folder)

value = np.load('cell_points.npy')
sum_x = [0] * 175
sum_x2 = [0] * 175
sum_x3 = [0] * 175

sum_z = [0] * 466
sum_z2 = [0] * 466
sum_z3 = [0] * 466

diff_x = [0] * 466
diff_x2 = [0] * 466
diff_x3 = [0] * 466

diff_z = [0] * 466
diff_z2 = [0] * 466
diff_z3 = [0] * 466

angle_x_save = [0] * 466
angle_x2_save = [0] * 466
angle_x3_save = [0] * 466

angle_z_save = [0] * 466
angle_z2_save = [0] * 466
angle_z3_save = [0] * 466


def set_equirectangluar_plot():
    # plt.xlim(-180, 180)
    plt.ylim(-180, 180)
    # plt.xticks(np.arange(-180.0, 181.0, step=45.0))
    plt.yticks(np.arange(-180.0, 181.0, step=30.0))
    plt.grid()

def plotting_point(x, y):
    ##ROund Cell
    r = 62  # radius of the object
    x_center = 80  # the x coordinate of the centre point xm
    y_center = 80  # the y coordinate of the cntre point ym
    ###############
    ##Potato Cell
    # r= 62
    # x_center=88
    # y_center=68

    # r = 120  # radius of the object
    # x_center = 215  # the x coordinate of the centre point xm
    # y_center = 150  # the y coordinate of the cntre point ym
    ############

    z_center = np.sqrt(
        abs(r * r - x_center * x_center - y_center * y_center))

    z = np.sqrt(r * r - (x_center - x) * (x_center - x) - (y_center - y) * (y_center - y)) + z_center

    # if flag2>0:
    #     z = np.sqrt(r * r - (x_center - x) * (x_center - x) - (y_center - y )* (y_center - y))
    # else:
    #     z=-np.sqrt(-(r * r - (x_center - x) * (x_center - x) - (y_center - y )* (y_center - y)))

    dx = x - x_center
    dy = y - y_center
    dz = z - z_center

    r_new=math.sqrt(r*r-dx*dx)
    #r_new=r*r-dy*dy

    angle_x = math.acos(dy/r_new)  # np.arctan(dz/dy),math.acos(dy/r)
    angle_y = math.asin(dx/r_new)  # np.arctan(dz/dx),math.acos(dx/r)
    angle_z = np.arctan(dy / dx)

    return  angle_x * 180 / np.pi, angle_y * 180 / np.pi, angle_z * 180 / np.pi#dx, dy,dz#


for i in range(0, len(value) - 1):  # i<466 range(0, len(value) - 1)
    angle_x, angle_y, angle_z = plotting_point(value[i][0][0], value[i][0][1])
    angle_x2, angle_y2, angle_z2 = plotting_point(value[i][1][0], value[i][1][1])
    angle_x3, angle_y3, angle_z3 = plotting_point(value[i][2][0], value[i][2][1])

    # if angle_x < 0: angle_x = angle_x + 180
    # if angle_x2 < 0: angle_x2 = angle_x2 + 180
    # if angle_x3 < 0: angle_x3 = angle_x3 + 180


    angle_x_save[i] = angle_x
    angle_x2_save[i] = angle_x2
    angle_x3_save[i] = angle_x3


    # if angle_y < 0: angle_y = angle_y + 180
    # if angle_y2 < 0: angle_y2 = angle_y2 + 180
    # if angle_y3 < 0: angle_y3 = angle_y3 + 180

    if angle_z < 0: angle_z = angle_z + 180
    if angle_z2 < 0: angle_z2 = angle_z2 + 180
    if angle_z3 < 0: angle_z3 = angle_z3 + 180

    angle_z_save[i] = angle_z
    angle_z2_save[i] = angle_z2
    angle_z3_save[i] = angle_z3


    # plt.plot(i,angle_x,'bo')
    # plt.plot(i, angle_x2, 'go')
    #plt.plot(i, angle_x3, 'ro')

    # plt.scatter(i, angle_x3, c='#D59EBA', linewidth=5, marker='v', s=1)
    # plt.xlabel('Frame')  #
    # plt.ylabel('Cell orientation [°]')
    # plt.xlim(0, 150)
    # plt.ylim(1, 140)

    # plt.plot(i,angle_y,'bo')#绕y轴的旋转量
    # plt.plot(i, angle_y2, 'go')
    # plt.plot(i, angle_y3, 'ro')
    #
    # plt.plot(i,angle_z,'bo')
    # plt.plot(i, angle_z2, 'go')
    # plt.plot(i, angle_z3, 'ro')

# np.save('angle_cell_x0', angle_x_save)
# np.save('angle_cell_x1', angle_x2_save)
# np.save('angle_cell_x2', angle_x3_save)
def angle_x_save_plot():
    #plt.figure(figsize=(2, 4))
    #plt.figure(dpi=50)
    for i in range(0, 147):
        if i > 0:

            diff_x[i] = angle_x_save[i] - angle_x_save[i - 1]
            # if abs(diff_x[i])>2:
            #     diff_x[i]=2
            sum_x[i] = sum_x[i - 1] + abs(diff_x[i])

            diff_x2[i] = angle_x2_save[i] - angle_x2_save[i - 1]
            # if abs(diff_x2[i])>2:
            #     diff_x2[i]=2
            sum_x2[i] = sum_x2[i - 1] + abs(diff_x2[i])

            diff_x3[i] = angle_x3_save[i] - angle_x3_save[i - 1]
            # if abs(diff_x3[i])>2:
            #     diff_x3[i]=2
            sum_x3[i] = sum_x3[i - 1] + abs(diff_x3[i])

            # if sum_x3[i]>112:
            #     sum_x3[i]=sum_x3[i]-10

            plt.scatter(i, sum_x3[i], c='#D59EBA', linewidth=5, marker='v', s=1)
            plt.xlabel('Frame')  #
            plt.ylabel('Cell orientation [°]')
            plt.xlim(0, 150)
            plt.ylim(1, 180)

            # plt.plot(i, sum_x[i], 'bo')
            # plt.plot(i, sum_x2[i], 'go')
            # plt.xlim((0, 25))
            # plt.ylim((0, 200))
            #plt.axis([0,27,0,200])
            # plt.plot(i, sum_x3[i], 'ro')
            plt.xlabel('Time [s]')  #
            plt.ylabel('Cell orientation [°]')

            plt.grid()

angle_x_save_plot()
plt.savefig(os.path.join(result_folder, "Rotation_angle.png"), dpi=300)
plt.show()
