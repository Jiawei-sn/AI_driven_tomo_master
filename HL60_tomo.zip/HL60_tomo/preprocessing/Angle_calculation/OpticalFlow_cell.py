import numpy as np
import cv2
from matplotlib import pyplot as plt
import os

config = {
    "font.family": 'sans-serif',
    "font.serif": ['Arial',],
    "font.size": 16,
    "mathtext.fontset": 'stixsans',
}
plt.rcParams.update(config)

result_folder = 'result'
if not os.path.exists(result_folder):
    os.makedirs(result_folder)

video = 'cell'

cap = cv2.VideoCapture(video + '.avi')
res = (160,160)
fourcc = cv2.VideoWriter_fourcc(*'MP4V')

video_path = os.path.join(result_folder, 'model_Tracked.mp4')
out = cv2.VideoWriter(video_path + '_Tracked.mp4', fourcc, 15.0, res)
# create figure for ploting
fig, (ax2, ax3) = plt.subplots(2, 1)

# params for ShiTomasi corner detection
feature_params = dict(maxCorners=3,
                      qualityLevel=0.04,
                      minDistance=4,
                      blockSize=4)

# Parameters for lucas kanade optical flow
lk_params = dict(winSize=(10, 10),
                 maxLevel=1,
                 criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
# Empty array
value = []
# Create some random colors
color = [[255, 229, 51], [0, 201, 182], [0, 0, 255]]

# Take first frame and find corners in it
ret, old_frame = cap.read()#
old_gray = cv2.cvtColor(old_frame, cv2.COLOR_BGR2GRAY)

p0 = cv2.goodFeaturesToTrack(old_gray, mask=None, **feature_params)
print(p0)
# Create a mask image for drawing purposes
mask = np.zeros_like(old_frame)
z = 0
while (1):
    z += 1

    ret, frame = cap.read()
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # calculate optical flow
    p1, st, err = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, p0, None, **lk_params)

    # Select good points
    good_new = p1[st == 1]
    good_old = p0[st == 1]
    value.append(good_old)
    # draw the tracks
    for i, (new, old) in enumerate(zip(good_new, good_old)):

        #if i==2:
        a, b = new.ravel()
        c, d = old.ravel()
        #mask = cv2.line(mask, (int(a),int(b)),(int(c),int(d)), color[i], 2)#.tolist()#保留过往路径(a,b)为起始坐标，(c,d)为终点坐标,2为线的厚度,
        frame = cv2.circle(frame, (int(a),int(b)), 1, color[i], -1)
    img =cv2.add(frame, mask)

    print(z) #to see how many frame
    out.write(img)

    # plotting
    # ax1.plot(good_old[0][0],good_old[0][1], 'ro')#X and Y point 1
    # ax1.plot(good_old[1][0],good_old[1][1], 'go')#X and Y point 2
    # ax1.plot(good_old[2][0],good_old[2][1], 'bo')#X and Y point 3
    ax2.set_xlim(0, 467)
    ax2.set_ylim(1, 140)
    ax2.plot(z, good_old[0][0], 'bo',linewidth=5)  # x with framerate point 1
    ax2.plot(z, good_old[1][0], 'go',linewidth=5)  # x with framerate point 2
    ax2.plot(z, good_old[2][0], 'ro',linewidth=5)  # x with framerate point 3
    # ax2.scatter(z, good_old[0][0], c='#FFDB75', linewidth=5, marker='v', s=1)
    # ax2.scatter(z, good_old[1][0], c='#006E60', linewidth=5, marker='v', s=1)
    # ax2.scatter(z, good_old[2][0], c='#D59EBA', linewidth=5, marker='v', s=1)

    ax3.set_xlim(0, 467)
    ax3.set_ylim(1, 140)
    ax3.plot(z, good_old[0][1], 'bo',linewidth=5)  # y with framerate point 1
    ax3.plot(z, good_old[1][1], 'go',linewidth=5)  # y with framerate point 2
    ax3.plot(z, good_old[2][1], 'ro',linewidth=5)  # y with framerate point 3
    # ax3.scatter(z, good_old[2][1], c='#D59EBA', linewidth=5, marker='v', s=1)

    # Now update the previous frame and previous points
    old_gray = frame_gray.copy()
    p0 = good_new.reshape(-1, 1, 2)
    if z == 467:
        break
out.release()
cv2.destroyAllWindows()

# np.save('cell',value)

'''
Plotting diagramm
'''
# labeling diagrams
# ax1.invert_yaxis()
# ax1.invert_xaxis()
# ax1.set_ylabel('X and Y')

ax2.set_ylabel('X (frame)')
ax2.set_xlabel('frame')
#ax3.invert_yaxis()
ax3.set_ylabel('Y (frame)')
ax3.set_xlabel('frame')

plt.savefig(os.path.join(result_folder, "coordinates_feature_points.png"), dpi=300)
plt.show()
