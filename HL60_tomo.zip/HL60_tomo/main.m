%%
clc;
clear all;
addpath("example_data\");
addpath("example_data\preprocessed_projections\");
file_path ='.\example_data\preprocessed_projections\';

%% load the calculated angle and processed frames
load('angle.mat');
img_path_list = dir(strcat(file_path,'*.jpg'));
img_num = length(img_path_list);
if img_num > 0 
        for j = 1:img_num 
            image_name = img_path_list(j).name;
            image =imread(strcat(file_path,image_name));
            image=padarray(image,[20,20]);
            %imshow(image)
            ImageData(:,:,j)=image;
         end
end

for N1 = 1:252
    sum_x2_180(N1)=sum_x2_new3(N1);
end

%% HL60 Cell Reconstruction
% imshow(squeeze(ImageData(90,:,:)))
for N2 = 1:size(image,1)%
    img2=squeeze(ImageData(N2,:,:));
    imshow(img2);%show sinogram
    figure(44);
    title('sinogram of the cell');

%     imwrite(uint8(img2),strcat(file_save_path_sinogram, prefix, num2str(N2), suffix), format);
    Layer3(:,:,N2)=iradon(squeeze(ImageData(N2,:,:)),sum_x2_180,'spline','Shepp-Logan');
end


%% display the reconstruced tomography
for N3 = 1:size(image,1)
    img3=Layer3(:,:,N3);
%     title('reconstructed tomography');
    imshow(img3);
end

